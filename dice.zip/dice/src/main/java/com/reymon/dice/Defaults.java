package com.reymon.dice;

public class Defaults {
	public final static Integer NO_OF_PIECE = 3;
	public final static Integer NO_OF_SIDE = 6;
	public final static Integer NO_OF_ROLLS = 100;

}
